<?PHP
include "../Core/promotionCore.php";

$promotionCoreInstance=new promotionCore();

if (isset($_POST["id"]))
 	{
    $promotionCoreInstance->supprimerpromotion($_POST["id"]);

	header('Location: afficherpromotion.php');
	}

?>