<?PHP
class promotion{

	private $id;
	private $pourcentage;
	private $date_d;
	private $date_f;
	private $description;


	function __construct($id,$pourcentage,$date_d,$date_f,$description){
		$this->id=$id;
		$this->pourcentage=$pourcentage;
		$this->date_d=$date_d;
		$this->date_f=$date_f;
		$this->description=$description;
	}
	
	function getid(){
		return $this->id;
	}

	function getpourcentage(){
		return $this->pourcentage;
	}
	function getdate_d(){
		return $this->date_d;
	}
	function getdate_f(){
		return $this->date_f;
	}

	
	function getdescription(){
		return $this->description;
	}

	

	function setid($id){
		$this->id=$id;
	}

	function setpourcentage($pourcentage){
		$this->pourcentage=$pourcentage;
	}
	function setdate_d($date_d){
		$this->date_d=$date_d;
	}
	function setdate_f($date_f){
		$this->date_f=$date_f;
	}
	
	function setdescription($description){
		$this->description=$description;
	}
	
}

?>