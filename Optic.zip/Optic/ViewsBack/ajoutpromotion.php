<?PHP

include "../Entities/promotion.php";
include "../Core/promotionCore.php";



if (isset($_POST['pourcentage']) and isset($_POST['date_d']) and isset($_POST['date_f']) and isset($_POST['description'])   ) { 	
    	

$promotionInstance = new promotion(0,$_POST['pourcentage'],$_POST['date_d'],$_POST['date_f'],$_POST['description']);

$promotionCoreInstance=new promotionCore();
$promotionCoreInstance->ajouterPromotion($promotionInstance);


//echo'<script>window.location.href = "index.php";</script>';
header('Location: afficherpromotion.php');

	
}
else{	
    echo "vérifier les champs";
}


?>