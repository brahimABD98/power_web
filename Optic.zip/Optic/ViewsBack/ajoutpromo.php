<?PHP
include("include/header.php");
include "../Entities/photo.php";
include "../Core/photoCore.php";




$id_produit=$_POST["id_produit"];
$id_promo=$_POST["id_promo"];
//var_dump($id_promo,$id_produit);
$connect = mysqli_connect("localhost", "root", "", "mybase");  
 $query = "UPDATE produit SET id_promo ='".$id_promo."' WHERE id ='".$id_produit."'";
 
 
 $result = mysqli_query($connect, $query);

echo'<script>window.location.href = "afficherpromotion.php";</script>';
?>

    	


