<?PHP

include "../config.php";

class promotionCore {




    function ajouterpromotion($promotion){

        $sql="insert into promotion (id,pourcentage,date_d,date_f,description)
        values (:id,:pourcentage,:date_d,:date_f,:description)";
        $sql2="insert into historique (description) values (:des)";

       
        $db = config::getConnexion();

        try{

        $req=$db->prepare($sql);
        $req2=$db->prepare($sql2);

        $id=$promotion->getid();
        $pourcentage=$promotion->getpourcentage();
        $date_d=$promotion->getdate_d();
        $date_f=$promotion->getdate_f();
        $description=$promotion->getDescription();

        $des = "une promotion de " .$pourcentage . " % a ete ajouter pour le : " . $date_d . " jusqua = ".$date_f;
         

        
        $req->bindValue(':id',$id);
        $req->bindValue(':pourcentage',$pourcentage);
        $req->bindValue(':date_d',$date_d);
        $req->bindValue(':date_f',$date_f);

        $req->bindValue(':description',$description);
        $req2->bindValue(':des',$des);  


  
       

        $req->execute();
        $req2->execute();
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
    }
    function afficherListpromotions(){
        //$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
        $sql="SElECT * From promotion";
        $db = config::getConnexion();
        try{
            $liste=$db->query($sql);
            return $liste;
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

     function recupererpromotion($id){
        $sql="SELECT * from promotion where id=$id";
        $db = config::getConnexion();
        try{
            $liste=$db->query($sql);
            return $liste;
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    
    function supprimerpromotion($id){

        $sql="DELETE FROM promotion where id= :id";
        $sql2="insert into historique (description) values (:des)";

        $db = config::getConnexion();
        $req=$db->prepare($sql);
        $req2=$db->prepare($sql2);

        $req->bindValue(':id',$id);
        $des = "une promotion de " .$pourcentage . " % a ete supprimer";
        $req2->bindValue(':des',$des);

        try{
            $req->execute();
            $req2->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    
     function modifierpromotion($promotion,$id){

        $sql="UPDATE promotion SET pourcentage=:pourcentage,date_d=:date_d,date_f=:date_f,description=:description WHERE id=:id";
        $sql2="insert into historique (description) values (:des)";
        $db = config::getConnexion();
       $db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
        try{
                $req=$db->prepare($sql);
                $req2=$db->prepare($sql2);
                
                $id=$promotion->getid();
                $pourcentage=$promotion->getpourcentage();
                $date_d=$promotion->getdate_d();
                $date_f=$promotion->getdate_f();
                $description=$promotion->getdescription();

                $des = "une promotion de " .$pourcentage . " % a ete modifier";


                $datas = array(':id'=>$id,':pourcentage'=>$pourcentage, ':date_d'=>$date_d, ':date_f'=>$date_f,':description'=>$description);
                var_dump($datas);
         $req->bindValue(':id',$id);
        $req->bindValue(':pourcentage',$pourcentage);
        $req->bindValue(':date_d',$date_d);
        $req->bindValue(':date_f',$date_f);
        $req->bindValue(':description',$description);

        $req2->bindValue(':des',$des);

        
        


                $s= $req->execute();
                $req2->execute();

                   // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
            echo " Les datas : " ;
            print_r($datas);
        }

    }

  

   /*
    function afficherListProgs(){
        //$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
        $sql="SElECT id,name,type,price,duree,calories,img,description,id_menu From programme";
        $db = config::getConnexion();
        try{
            $liste=$db->query($sql);
            return $liste;
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

    function supprimerProg($id){

        $sql="DELETE FROM programme where id= :id";

        $db = config::getConnexion();
        $req=$db->prepare($sql);
        $req->bindValue(':id',$id);
        try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }

    function modifierProg($prog,$id){

        $sql="UPDATE programme SET name=:name,type=:type,price=:price,duree=:duree,calories=:calories,img=:img,description=:description,id_menu=:id_menu WHERE id=:id";

        $db = config::getConnexion();
        //$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
        try{
                $req=$db->prepare($sql);

                $name=$prog->getName();
                $type=$prog->getType();
                $price=$prog->getPrice();
                $duree=$prog->getDuree();
                $img=$prog->getImg();
                $calories=$prog->getCalories();
                $description=$prog->getDescription();
                $id_menu=$prog->getIdMenu();

                $datas = array(':id'=>$id,':name'=>$name, ':type'=>$type, ':price'=>$price,':duree'=>$duree,':calories'=>$calories,':img'=>$img,':description'=>$description,':id_menu'=>$id_menu);

                $req->bindValue(':name',$name);
                $req->bindValue(':id',$id);
                $req->bindValue(':type',$type);
                $req->bindValue(':price',$price);
                $req->bindValue(':duree',$duree);

                $req->bindValue(':calories',$calories);
                $req->bindValue(':img',$img);
                $req->bindValue(':description',$description);
                $req->bindValue(':id_menu',$id_menu);


                $s= $req->execute();

                   // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
            echo " Les datas : " ;
            print_r($datas);
        }
    }


    function recupererProg($id){
        $sql="SELECT * from programme where id=$id";
        $db = config::getConnexion();
        try{
            $liste=$db->query($sql);
            return $liste;
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    
    function rechercherListeEmployes($tarif){
        $sql="SELECT * from employe where tarifHoraire=$tarif";
        $db = config::getConnexion();
        try{
        $liste=$db->query($sql);
        return $liste;
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
*/
}

?>