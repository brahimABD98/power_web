-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mar. 10 déc. 2019 à 09:34
-- Version du serveur :  5.7.24
-- Version de PHP :  7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `mybase`
--

-- --------------------------------------------------------

--
-- Structure de la table `historique`
--

DROP TABLE IF EXISTS `historique`;
CREATE TABLE IF NOT EXISTS `historique` (
  `description` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `historique`
--

INSERT INTO `historique` (`description`) VALUES
('une promotion de35 % a ete ajouter pour le : 2019-12-13 jusqua = 2019-12-20'),
('une promotion de 87 % a ete ajouter pour le : 2019-12-13 jusqua = 2019-12-19'),
('une promotion de50 % a ete modifier'),
('une promotion de 3 % a ete modifier'),
('une promotion de  % a ete supprimer'),
('une promotion de 30 % a ete ajouter pour le : 2019-12-18 jusqua = 2019-12-26');

-- --------------------------------------------------------

--
-- Structure de la table `photo`
--

DROP TABLE IF EXISTS `photo`;
CREATE TABLE IF NOT EXISTS `photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(255) NOT NULL,
  `id_photo` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `photo`
--

INSERT INTO `photo` (`id`, `img`, `id_photo`) VALUES
(1, '68949199_1444261922379716_172541351815020544_n.jpg', 42),
(2, 'produit1.jpg', 42),
(3, 'produit2.jpg', 43),
(4, 'Capture.PNG', 44),
(5, '68949199_1444261922379716_172541351815020544_n.jpg', 45),
(6, '71281503_1472905529515355_962420059848835072_n.jpg', 46);

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

DROP TABLE IF EXISTS `produit`;
CREATE TABLE IF NOT EXISTS `produit` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `marque` varchar(10) NOT NULL,
  `prix` float NOT NULL,
  `type` varchar(10) NOT NULL,
  `categorie` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `quantite` int(100) NOT NULL,
  `id_promo` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`id`, `marque`, `prix`, `type`, `categorie`, `description`, `quantite`, `id_promo`) VALUES
(43, 'RayBan', 30, 'Femme', 'Lunettes de vue', 'djjjj', 6, 11),
(44, 'dsqdqs', 50, 'Femme', 'Lunettes de vue', 'dedffede', 50, 9),
(45, 'kasq', 70, 'Enfant', 'Lunettes avec applique', 'ssdqs', 60, 7),
(46, 'dsd', 70, 'Homme', 'Lunettes de vue', 'ddsdsd', 60, 12);

-- --------------------------------------------------------

--
-- Structure de la table `promotion`
--

DROP TABLE IF EXISTS `promotion`;
CREATE TABLE IF NOT EXISTS `promotion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pourcentage` int(2) NOT NULL,
  `date_d` date NOT NULL,
  `date_f` date NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `promotion`
--

INSERT INTO `promotion` (`id`, `pourcentage`, `date_d`, `date_f`, `description`) VALUES
(5, 3, '2019-12-12', '2019-12-14', 'vvv'),
(7, 45, '2019-12-04', '2019-12-04', 'ioio'),
(8, 22, '2019-12-12', '2019-12-26', 'fgg'),
(9, 50, '2019-12-12', '2019-12-19', 'yyy'),
(12, 30, '2019-12-18', '2019-12-26', 'dssdqdsqd'),
(11, 87, '2019-12-13', '2019-12-19', 'ggg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
